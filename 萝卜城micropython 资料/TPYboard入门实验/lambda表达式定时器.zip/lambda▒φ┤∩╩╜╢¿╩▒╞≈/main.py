from pyb import Timer
tim = Timer(1, freq=1)
tim.callback(lambda t: pyb.LED(1).toggle())