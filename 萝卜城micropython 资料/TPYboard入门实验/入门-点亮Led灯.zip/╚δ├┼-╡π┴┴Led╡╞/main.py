# main.py -- put your code here!
import pyb
pyb.LED(2).on()
 