from pyb import Timer
i = 0
def f(t):
    global i
    i = (i+1)%255
    pyb.LED(4).intensity(i)
tm=Timer(4, freq=100, callback=f)