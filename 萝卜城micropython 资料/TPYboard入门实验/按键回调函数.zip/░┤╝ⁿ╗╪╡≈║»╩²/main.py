import pyb
sw=pyb.Switch()
led=pyb.LED(4)
def test():
    led.toggle()
sw.callback(test)