import pyb
sw=pyb.Switch()
led=pyb.LED(1)
led3=pyb.LED(3)
while True:
    sw_state=sw()
    if sw_state:
        led.on()
        led3.off()
    else:
        led.off()
        led3.on()
