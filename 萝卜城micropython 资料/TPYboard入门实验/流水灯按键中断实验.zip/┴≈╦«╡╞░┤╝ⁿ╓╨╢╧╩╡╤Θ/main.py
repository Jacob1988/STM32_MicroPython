# main.py -- put your code here!
import pyb
sw=pyb.Switch()
def test():
    pyb.LED(4).on()
    pyb.delay(1000)
    pyb.LED(4).off()
sw.callback(test)


while True:
  pyb.LED(1).on()
  pyb.delay(1000)
  pyb.LED(1).off()
  pyb.LED(2).on()
  pyb.delay(1000)
  pyb.LED(2).off()
  pyb.LED(3).on()
  pyb.delay(1000)
  pyb.LED(3).off()
  pyb.LED(1).on()
